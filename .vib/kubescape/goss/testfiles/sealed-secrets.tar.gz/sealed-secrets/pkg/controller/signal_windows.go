package controller

func initKeyGenSignalListener(trigger func()) {}
