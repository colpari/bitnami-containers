---
version: latest
cascade:
  layout: docs
---

# Sealed Secrets documentation

Explore the [latest version docs](./latest/) to get started.
